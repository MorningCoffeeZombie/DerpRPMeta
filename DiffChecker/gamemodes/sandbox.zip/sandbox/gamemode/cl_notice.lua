
function GM:AddNotify( str, type, length )

	notification.AddLegacy( str, type, length )

end

function GM:PaintNotes()
end
