
-- Tool should return true if freezing the view angles
function ToolObj:FreezeMovement()
	return false 
end

-- The tool's opportunity to draw to the HUD
function ToolObj:DrawHUD()
end
