These tools were removed due to potential to harm the server.
Their original location is: (in the server)
/garrysmod/gamemodes/sandbox/entities/weapons/gmod_tool/stools/

They were placed in a folder named "!DEPRECATED_BANNED_TOOLS" by DrDerpenstein (aka MorningCoffeeZombie) on 8/1/2019.
