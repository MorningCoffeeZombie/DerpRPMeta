AddCSLuaFile()
function start()
Myself = LocalPlayer()

local Frame = vgui.Create( "DFrame" )
if MColor == nil then
MColor = Color(150,0,255,150)
end
if ButtonColor == nil then
ButtonColor = Color(255, 255 ,255, 255)
end
if ButtonColor == nil then
TextColor = Color(0, 0 ,0, 255)
end

Frame:SetTitle( "Act Command" )
Frame:SetSize( 470, 500 )
Frame:Center()
Frame:MakePopup()
Frame.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, MColor ) 
end


/////////////////////////////////////////////////////////////////////////////
local sheet = vgui.Create( "DPropertySheet", Frame )
sheet:Dock( FILL )

local panel1 = vgui.Create( "DPanel", sheet )
panel1.Paint = function( self, w, h )  end
sheet:AddSheet( "Acts", panel1, "icon16/user_gray.png" )



local panel2 = vgui.Create( "DPanel", sheet )
panel2.Paint = function( self, w, h ) end
sheet:AddSheet( "Color Mixer", panel2, "icon16/color_wheel.png" )

local ColorPicker = vgui.Create( "DColorMixer", panel2 )
ColorPicker:SetSize( 300, 300 )
ColorPicker:SetPos(5,5)
ColorPicker:SetPalette( true )
ColorPicker:SetAlphaBar( true )
ColorPicker:SetWangs( true )
ColorPicker:SetColor( Color( 255, 255, 255 ) ) 

 
local List = vgui.Create("DListView")
List:SetParent(panel2)
List:SetPos(320, 5)
List:SetSize(120, 300)
List:SetMultiSelect(false)
List:AddColumn("Name")
List:AddLine("Menu Color")
List:AddLine("Button Color")
List:AddLine("Text Color")


local ApplyColor = vgui.Create( "DButton", panel2 )
ApplyColor:SetText( "Apply Color!" )
ApplyColor:SetTextColor( TextColor )
ApplyColor:SetPos( 20 , 350 )
ApplyColor:SetSize( 400, 50 )
ApplyColor.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor )
end
ApplyColor.DoClick = function()
local Selected = List:GetSelectedLine()
if Selected == 1 then MColor = ColorPicker:GetColor() end			 
if Selected == 2 then ButtonColor = ColorPicker:GetColor() end		 
if Selected == 3 then TextColor = ColorPicker:GetColor() end	   
	 
end
//////////////////////////////////////////////////////////////////////////////////////
local Dance = vgui.Create( "DButton", panel1 )
Dance:SetText( "Act Dance" )
Dance:SetTextColor( TextColor )
Dance:SetPos( 5, 20 )
Dance:SetSize( 100, 30 )
Dance.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor )
end
Dance.DoClick = function()
				Myself:ConCommand("act dance")
end


local Zombie = vgui.Create( "DButton", panel1 )
Zombie:SetText( "Act Zombie" )
Zombie:SetTextColor( TextColor )
Zombie:SetPos( 115, 20 )
Zombie:SetSize( 100, 30 )
Zombie.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor )
end
Zombie.DoClick = function()
				Myself:ConCommand("act zombie")
end

local Robot = vgui.Create( "DButton", panel1 )
Robot:SetText( "Act Robot" )
Robot:SetTextColor( TextColor )
Robot:SetPos( 225, 20 )
Robot:SetSize( 100, 30 )
Robot.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Robot.DoClick = function()
				Myself:ConCommand("act robot")
end

local Agree = vgui.Create( "DButton", panel1 )
Agree:SetText( "Act Agree" )
Agree:SetTextColor( TextColor )
Agree:SetPos( 335, 20 )
Agree:SetSize( 100, 30 )
Agree.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Agree.DoClick = function()
				Myself:ConCommand("act agree")
end

local Becon = vgui.Create( "DButton", panel1 )
Becon:SetText( "Act Becon" )
Becon:SetTextColor( TextColor )
Becon:SetPos( 5, 60 )
Becon:SetSize( 100,30 )
Becon.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Becon.DoClick = function()
				Myself:ConCommand("act becon")
end

local Bow = vgui.Create( "DButton", panel1 )
Bow:SetText( "Act Bow" )
Bow:SetTextColor( TextColor )
Bow:SetPos( 115, 60 )
Bow:SetSize( 100, 30 )
Bow.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Bow.DoClick = function()
				Myself:ConCommand("act bow")
end

local Cheer = vgui.Create( "DButton", panel1 )
Cheer:SetText( "Act Cheer" )
Cheer:SetTextColor( TextColor )
Cheer:SetPos( 225, 60 )
Cheer:SetSize( 100, 30 )
Cheer.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Cheer.DoClick = function()
				Myself:ConCommand("act cheer")
end

local Disagree = vgui.Create( "DButton", panel1 )
Disagree:SetText( "Act Disagree" )
Disagree:SetTextColor( TextColor )
Disagree:SetPos( 335, 60 )
Disagree:SetSize( 100, 30 )
Disagree.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Disagree.DoClick = function()
				Myself:ConCommand("act disagree")
end

local Forward1 = vgui.Create( "DButton", panel1 )
Forward1:SetText( "Act Forward" )
Forward1:SetTextColor( TextColor )
Forward1:SetPos( 5, 100 )
Forward1:SetSize( 100, 30 )
Forward1.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Forward1.DoClick = function()
				Myself:ConCommand("act forward")
end

local Group = vgui.Create( "DButton", panel1 )
Group:SetText( "Act Group" )
Group:SetTextColor( TextColor )
Group:SetPos( 115, 100 )
Group:SetSize( 100, 30 )
Group.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Group.DoClick = function()
				Myself:ConCommand("act group")
end

local Halt = vgui.Create( "DButton", panel1 )
Halt:SetText( "Act Halt" )
Halt:SetTextColor( TextColor )
Halt:SetPos( 225, 100 )
Halt:SetSize( 100, 30 )
Halt.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Halt.DoClick = function()
				Myself:ConCommand("act halt")
end

local Laugh = vgui.Create( "DButton", panel1 )
Laugh:SetText( "Act Laugh" )
Laugh:SetTextColor( TextColor )
Laugh:SetPos( 335, 100 )
Laugh:SetSize( 100, 30 )
Laugh.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Laugh.DoClick = function()
				Myself:ConCommand("act laugh")
end

local Muscle = vgui.Create( "DButton", panel1 )
Muscle:SetText( "Act Muscle" )
Muscle:SetTextColor( TextColor )
Muscle:SetPos( 5, 140 )
Muscle:SetSize( 100, 30 )
Muscle.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Muscle.DoClick = function()
				Myself:ConCommand("act muscle")
end

local Pers = vgui.Create( "DButton", panel1 )
Pers:SetText( "Act Pers" )
Pers:SetTextColor( TextColor )
Pers:SetPos( 115, 140 )
Pers:SetSize( 100, 30 )
Pers.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Pers.DoClick = function()
				Myself:ConCommand("act pers")
end

local Salute = vgui.Create( "DButton", panel1 )
Salute:SetText( "Act Salute" )
Salute:SetTextColor( TextColor )
Salute:SetPos( 225, 140 )
Salute:SetSize( 100, 30 )
Salute.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Salute.DoClick = function()
				Myself:ConCommand("act salute")
end

local Wave = vgui.Create( "DButton", panel1 )
Wave:SetText( "Act Wave" )
Wave:SetTextColor( TextColor )
Wave:SetPos( 335, 140 )
Wave:SetSize( 100, 30 )
Wave.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, ButtonColor ) 
end
Wave.DoClick = function()
				Myself:ConCommand("act wave")
end


end

concommand.Add( "act_menu", function( ply, cmd, args )
		  start()
end )

concommand.Add( "act_menu_color", function( ply, cmd, args )
		  MColor = Color(args[1], args[2],args[3] ,args[4])
		  print( MColor )
end )

concommand.Add( "act_menu_button_color", function( ply, cmd, args )
		  ButtonColor = Color(args[1], args[2],args[3] ,args[4])
		  print( ButtonColor)
end )

concommand.Add( "act_menu_text_color", function( ply, cmd, args )
		  TextColor = Color(args[1], args[2],args[3] ,args[4])
		  print( TextColor )
end )

-- act agree
-- act becon
-- act bow
-- act cheer
-- act dance
-- act disagree
-- act forward
-- act group
-- act halt
-- act laugh
-- act muscle
-- act pers
-- act robot
-- act salute
-- act wave
-- act zombie


