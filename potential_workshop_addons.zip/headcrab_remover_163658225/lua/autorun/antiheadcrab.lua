if ( SERVER ) then
 
        //Server
 
        local function RemoveCrabs()
        
                local Crabs = table.Add( table.Add( table.Add( ents.FindByClass( "npc_headcrab" ), ents.FindByClass( "npc_headcrab_fast" ) ), ents.FindByClass( "npc_headcrab_black" ) ), ents.FindByClass( "npc_headcrab_poison" ) )
                
                for _, crab in pairs( Crabs ) do
                        
                        SafeRemoveEntity( crab )
                end
        end
        
        hook.Add( "Think", "No_Crabs", RemoveCrabs )
else
 
        //Client
 
        local function RemoveCrabs()
        
                local Crabs =  ents.GetAll()
                
                for _, crab in pairs( Crabs ) do
                
                        if ( crab:GetClass():lower():find( "ragdoll" ) && ( crab:GetModel():find( "headcrab" ) || crab:GetModel():find( "lamarr" ) ) ) then
                        
                                SafeRemoveEntity( crab )
                        end
                end
        end
        
        hook.Add( "Think", "No_Crabs", RemoveCrabs )
end