ENT.Base = "base_ai" 
ENT.Type = "ai"
ENT.AutomaticFrameAdvance = true

ENT.PrintName = "Gun License Dealer"
ENT.Author = "Church"
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetAutomaticFrameAdvance( bUsingAnim )
	self.AutomaticFrameAdvance = bUsingAnim
end