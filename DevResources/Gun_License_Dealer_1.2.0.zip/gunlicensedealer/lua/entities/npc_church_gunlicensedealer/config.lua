Config = Config or {}

--[[-------------------------------
Gun License Dealer Config
-------------------------------]]--

-- Admin ranks that have perms to all functions (saving/removing/placing)
Config.AdminRanks = {
	"admin",
	"superadmin"
}
-- Price for the license
Config.SellPrice = 750
-- Display message if you already have a license
Config.HasLicense = "You already have a gun license."
-- Model for the dealer
Config.DealerModel = "models/breen.mdl"
-- Command to place the NPC
Config.PlaceNPC = "placeGunNPC"
-- Command to save latest placed NPC
Config.SaveNPC = "saveGunNPC"
-- Command to save all NPC's on map [OVERWRITES OLD SAVE FILE AND REPLACES WITH ALL CURRENT NPCS ON MAP]
Config.SaveAllNPC = "saveallGunNPC"
-- Command to remove saved NPC's [THIS REMOVES ALL OF THEM]
Config.RemoveNPC = "removeGunNPC"
-- Command to reload all NPC's [REMOVES ALL NON-SAVED]
Config.ReloadNPC = "reloadGunNPC"
-- Does tool gun remove the NPC from the map? [This is a temporary removal, use the command to permanently remove]
Config.ToolGunRemove = true
-- Can players purchase licenses when THERE IS a mayor? [TRUE MEANS THERE CANNOT BE A MAYOR IF YOU WANT TO PURCHASE]
Config.MayorCheck = true
-- Your mayor team
Config.MayorTeam = TEAM_MAYOR
-- Message to display if mayor is active and attempt to purchase license
Config.MayorMessage = "You cannot purchase a license while there is a mayor!"