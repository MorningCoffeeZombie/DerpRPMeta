AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
AddCSLuaFile("config.lua")
include("shared.lua")
include("config.lua")

util.AddNetworkString( "DrawMenu" )
util.AddNetworkString( "Purchased" )

function CheckAdmin(ply)
	local admins = Config.AdminRanks
  for index, value in ipairs(admins) do 
		if ply:GetUserGroup() == value then
			return true
		end
	end
	return false
end

function ENT:Initialize()
	self:SetModel(Config.DealerModel)
	self:SetHullType( HULL_HUMAN )
	self:SetHullSizeNormal( )
	self:SetNPCState( NPC_STATE_SCRIPT )
	self:SetSolid(  SOLID_BBOX )
	self:CapabilitiesAdd(CAP_ANIMATEDFACE)
	self:SetUseType( SIMPLE_USE )
	self:DropToFloor()
	self:SetName("Gun License Dealer")
 	self:SetUseType(SIMPLE_USE)
	self:SetMaxYawSpeed( 90 )
end

function ENT:PhysgunPickup(ply, ent)
	return CheckAdmin(ply)
end

function ENT:SpawnFunction(ply, tr)
	if (!tr.HitWorld) then return end
 
	local ent = ents.Create("npc_church_gunlicensedealer")
	ent:SetPos(tr.HitPos + Vector(0, 0, 25))
	ent:Spawn()

	return ent
end

function ENT:AcceptInput(name, activator, caller)
	-- If mayor check is active
	if Config.MayorCheck then
		-- If there is a mayor, show message
		if #team.GetPlayers(Config.MayorTeam) > 0 then
			-- Message set in config
			DarkRP.notify(caller, 1, 5, Config.MayorMessage )
		else
			-- If no mayor & check is active, do the purcahse
			if (name == "Use" && IsValid(caller) && caller:IsPlayer()) then
				umsg.Start("DrawMenu", caller)
				umsg.End()
			end
		end
	-- If no mayor check, just do the license purcahse
	else
		if (name == "Use" && IsValid(caller) && caller:IsPlayer()) then
			umsg.Start("DrawMenu", caller)
			umsg.End()
		end
	end
end

function ENT:CanTool(ply, trace, tool, ent)
	if CheckAdmin(ply) and tool == "remover" then
		DarkRP.notify(ply, 3, 5, "To remove a GLD permanently, use the console command " .. Config.RemoveNPC)
		return Config.ToolGunRemove
	end
end

net.Receive("Purchased", function(len, ply)
	if !ply:getDarkRPVar("HasGunlicense") then
		ply:setDarkRPVar("HasGunlicense", true)
		ply:addMoney(-1 * Config.SellPrice)
		DarkRP.notify(ply, 4, 5, "Purchased a license!")
	else
		DarkRP.notify(ply, 1, 5, "You already have a gun license.")
	end
end)

local latestGLDPos, latestGLDAng
function placeGunNPC(ply)
	if CheckAdmin(ply) then
		local npcSetAng = ply:GetAngles()
		local npcSetPos = ply:GetPos()
		local ent = ents.Create("npc_church_gunlicensedealer")
		ent:SetPos(npcSetPos)
		ent:SetAngles(npcSetAng)
		ent:Spawn()
		DarkRP.notify(ply, 3, 5, "Use the save command " .. Config.SaveNPC .. " in console to save the NPC.")
		DarkRP.notify(ply, 3, 5, "This will only save the most recent one.")
		latestGLDPos = ent:GetPos()
		latestGLDAng = ent:GetAngles()
	end
end

function saveGunNPC(ply)
	if CheckAdmin(ply) then
		local posValuesTable = string.Split(tostring(latestGLDPos), " ")
		local angValuesTable = string.Split(tostring(latestGLDAng), " ")
		local posTable = string.Implode(";", posValuesTable)
		local angTable = string.Implode(";", angValuesTable)
		if file.Exists("GLDlocations.txt", "DATA") then
			file.Append("GLDlocations.txt", "\n" .. posTable .. ";" .. angTable .. ";")
		else
			file.Write("GLDlocations.txt", posTable .. ";" .. angTable .. ";")
			print("\n**************************************************************************")
			print("* First time saving, creating data file and writing...")
			print("**************************************************************************")
		end
		
		print("\n**************************************************************************")
		print("*")
		print("* Saved Gun License Dealer!")
		print("*")
		print("**************************************************************************")
		
		ply:PrintMessage( HUD_PRINTCONSOLE, "\n\n**************************************************************************\n*\n* Saved Gun License Dealer!\n*\n**************************************************************************" )
	end
end

function saveAllNPC(ply)
	if CheckAdmin(ply) then
		if file.Exists("GLDlocations.txt", "DATA") then
			file.Write("GLDlocations.txt", "")
		else
			file.Write("GLDlocations.txt", "")
			print("\n**************************************************************************")
			print("* First time saving, creating data file and writing...")
			print("**************************************************************************")
		end
		for k, ent in ipairs(ents.FindByClass("npc_church_gunlicensedealer")) do
			local posValuesTable = string.Split(tostring(ent:GetPos()), " ")
			local angValuesTable = string.Split(tostring(ent:GetAngles()), " ")
			local posTable = string.Implode(";", posValuesTable)
			local angTable = string.Implode(";", angValuesTable)
			file.Append("GLDlocations.txt", "\n" .. posTable .. ";" .. angTable .. ";")
		end
		print("\n**************************************************************************")
		print("*")
		print("* Saved all Gun License Dealers!")
		print("*")
		print("**************************************************************************")
		ply:PrintMessage( HUD_PRINTCONSOLE, "\n\n**************************************************************************\n*\n* Saved all Gun License Dealers!\n*\n**************************************************************************" )
	end
end

function reloadGunNPC(ply)
	if CheckAdmin(ply) then
		if file.Exists("GLDlocations.txt", "DATA") then
			for k, v in pairs(ents.FindByClass("npc_church_gunlicensedealer")) do
				v:Remove()
			end
			local saveFile = file.Read("GLDlocations.txt", "DATA")
			local indivLines = string.Explode("\n", saveFile)
			--PrintTable(indivLines) -- Re-enable for debugging, prints the save file to sevrer-side console.
			for i, line in ipairs(indivLines) do
				local data = string.Explode(";", line)
				posx = tonumber(data[1])
				posy = tonumber(data[2])
				posz = tonumber(data[3])
				ang1 = tonumber(data[4])
				ang2 = tonumber(data[5])
				ang3 = tonumber(data[6])
				local ent = ents.Create("npc_church_gunlicensedealer")
				ent:SetPos(Vector(posx, posy, posz))
				ent:SetAngles(Angle(ang1, ang2, ang3))
				ent:Spawn()
			end
			ply:PrintMessage(HUD_PRINTCONSOLE, "\n\n**************************************************************************\n*\n* All Gun License Dealers reloaded and respawned!\n*\n**************************************************************************" )
			ply:PrintMessage(HUD_PRINTTALK, "All GLD's reloaded and respawned!")
		else
			print("\n**************************************************************************")
			print("* No save file found! Is this a mistake or do you not have any saved?")
			print("**************************************************************************")
			ply:PrintMessage( HUD_PRINTCONSOLE, "\n\n**************************************************************************\n*\n* No save file found! Is this a mistake or do you not have any saved?\n*\n**************************************************************************" )
		end
	end
end

function removeGunNPC(ply)
	if CheckAdmin(ply) then
		for k, v in pairs(ents.FindByClass("npc_church_gunlicensedealer")) do
				v:Remove()
		end
		file.Write("GLDlocations.txt", "")
		DarkRP.notify(ply, 1, 5, "REMOVED ALL GLD'S PERMANENTLY")
		print("\n\n**************************************************************************\n*\n* Removed all Gun License Dealers Permanently!\n*\n**************************************************************************" )
	end
end

concommand.Add(Config.PlaceNPC,  placeGunNPC) -- Place NPC command
concommand.Add(Config.SaveNPC,   saveGunNPC) -- Save NPC command
concommand.Add(Config.RemoveNPC, removeGunNPC) -- Remove NPC command
concommand.Add(Config.ReloadNPC, reloadGunNPC) -- Reload NPC command
concommand.Add(Config.SaveAllNPC, saveAllNPC) -- Save All NPC command