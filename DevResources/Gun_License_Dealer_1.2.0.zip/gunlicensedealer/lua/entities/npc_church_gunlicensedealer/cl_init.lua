include("shared.lua")
include("config.lua")

price = Config.SellPrice

function ENT:Draw()
	self.Entity:DrawModel()
	
	local pos = self:GetPos()
	pos.z = (pos.z + 15)
	local ang = self:GetAngles()
	
	surface.SetFont("CloseCaption_Bold")
	local title = "Gun License Dealer"
	local tw = surface.GetTextSize(title)

	ang:RotateAroundAxis(ang:Forward(), 90)
	local textang = ang

	textang:RotateAroundAxis(textang:Right(), CurTime() * -180)

	cam.Start3D2D(pos + ang:Right() * -30, textang, 0.2)
		draw.WordBox(3, -tw *0.5 + 5, -180, title, "CloseCaption_Bold", Color(0,0,0,150), color_white)
	cam.End3D2D()
	
end

local function DrawMenu()
		CloseDermaMenus()
    local DermaPanel = vgui.Create("DFrame")
    DermaPanel:SetSize(ScrW() * 0.125, ScrH() * 0.093)
    DermaPanel:Center()
    DermaPanel:SetTitle('Gun License Dealer')
    DermaPanel:ShowCloseButton(true)
    DermaPanel:SetSizable(false)
    DermaPanel:SetDeleteOnClose(true)
		DermaPanel:SetBackgroundBlur(true)
    DermaPanel:MakePopup()
		
		local Label1 = vgui.Create( "DLabel", DermaPanel )
		Label1:SetText("Purchase a gun license?")
		Label1:CenterHorizontal(0.4)
		Label1:CenterVertical(0.38)
		Label1:SizeToContents()
	
		local Label2 = vgui.Create( "DLabel", DermaPanel )
		Label2:SetText("It costs $" .. price)
		Label2:CenterHorizontal(0.51)
		Label2:CenterVertical(0.53)
		Label2:SizeToContents()
		
		local Confirm = vgui.Create("DButton", DermaPanel)
		Confirm:SetText("Purchase")
		Confirm:SetTextColor(Color(0,0,0))
		Confirm:SetWidth(DermaPanel:GetWide() * 0.8)
		Confirm:CenterHorizontal(0.5)
		Confirm:CenterVertical(0.7)
		Confirm.DoClick = function()
			DermaPanel:Close()
			net.Start("Purchased")
			net.SendToServer()
		end
end
usermessage.Hook("DrawMenu", DrawMenu)