version = "1.2.0"
sfLink = "http://google.com/"
sfProfile = "http://scriptfodder.com/users/view/76561198185681028"
contact = "doommarine93@gmail.com"

print("\n\n\n**************************************************************************")
print("* Gun License Dealer by Church")
print("**************************************************************************")
print("*")
print("* [Version]........[" .. version.. "]")
print("* [SF Profile].....[" .. sfProfile .. "]")
print("* [Contact]........[" .. contact .. "]")
print("*")
print("**************************************************************************")
print("* Loading all NPC's...")
print("**************************************************************************")

function SpawnNPC()
	if file.Exists("GLDlocations.txt", "DATA") then
		local saveFile = file.Read("GLDlocations.txt", "DATA")
		local indivLines = string.Explode("\n", saveFile)
		for i, line in ipairs(indivLines) do
			local data = string.Explode(";", line)
			posx = tonumber(data[1])
			posy = tonumber(data[2])
			posz = tonumber(data[3])
			ang1 = tonumber(data[4])
			ang2 = tonumber(data[5])
			ang3 = tonumber(data[6])
			local ent = ents.Create("npc_church_gunlicensedealer")
			ent:SetPos(Vector(posx, posy, posz))
			ent:SetAngles(Angle(ang1, ang2, ang3))
			ent:Spawn()
		end
		print("**************************************************************************")
		print("* [Gun License Dealers]")
		print("*")
		print("* Done loading NPC's.")
		print("**************************************************************************")
	else
		print("**************************************************************************")
		print("*")
		print("* [Gun License Dealers]")
		print("*")
		print("* No GLDlocations.txt file found, assuming no NPC's saved.")
		print("* On first NPC save, file will be created.")
		print("*")
		print("**************************************************************************")
	end
end

hook.Add( "InitPostEntity", "SpawnNPC", SpawnNPC)